all help informations are in https://github.com/Spartanzhao/Annoroad-OMIC-Viz
