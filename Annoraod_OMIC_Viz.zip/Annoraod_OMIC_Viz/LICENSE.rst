License		Description

apache-2	Apache License, version 2.0
bsd-3		BSD License 3.0 ("New/Revised BSD License")
bsd-2		BSD License 2.0 ("Free BSD License")
gpl-3		GNU General Public License 3.0
lgpl-3		GNU Lesser General Public License 3.0
mit		MIT License
mpl-2		Mozilla Public License, version 2.0
none		Public domain (+liability, warranty)
closed		Closed source license template

Need help deciding? See:
https://opensource.org/licenses
https://choosealicense.com/licenses
